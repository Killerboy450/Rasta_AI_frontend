@echo off
setlocal
cd /d "%~dp0manager-web"
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js 24, then reopen this launcher.
  pause
  exit /b 1
)
if not exist node_modules (
  call npm ci --no-audit --no-fund
  if errorlevel 1 (
    echo Dependency installation failed. Check the error above.
    pause
    exit /b 1
  )
)
echo Manager frontend: http://localhost:5173
echo Sign-in and data require your configured backend. Read README_TASK2.md.
call npm run dev -- --host localhost --open
pause
