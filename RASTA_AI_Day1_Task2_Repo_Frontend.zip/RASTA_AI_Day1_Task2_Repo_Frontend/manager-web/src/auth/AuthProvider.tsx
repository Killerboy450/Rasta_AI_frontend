/**
 * Session state for the manager app.
 *
 * `permissions` comes from the server and drives what the UI *renders*. It is
 * never an authorization decision - the backend re-checks every request, so
 * hiding a button is a courtesy, not a control.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'

import {
  api,
  refreshSession,
  setAccessToken,
  setUnauthenticatedHandler,
  type AuthenticatedUser,
} from '../api/client'
import { clearCache } from '../api/connectivity'

/**
 * THIS SITE IS THE MANAGER CONSOLE. A driver's credentials authenticate - the
 * backend is one identity service - but a driver gets no console: the session
 * is revoked server-side (refresh cookie), cleared here, and the login page
 * says why. Checked on login AND on silent restore, so a driver who signed in
 * elsewhere cannot reload this site into a manager shell.
 */
// The authorised reviewer is a console user by design (Review screen): they
// hold trip:read / route:read / route:review_authorize and nothing else, and
// the nav + Guarded routes already scope them. Drivers stay refused.
export const CONSOLE_ROLES: readonly string[] = ['MANAGER', 'ADMIN', 'AUTHORISED_REVIEWER']
export const MANAGER_ACCOUNT_REQUIRED = 'Manager account required.'

export class ManagerAccountRequiredError extends Error {
  constructor() {
    super(MANAGER_ACCOUNT_REQUIRED)
    this.name = 'ManagerAccountRequiredError'
  }
}

/** Identity from the server; a non-console role is signed out before it lands. */
async function consoleIdentity() {
  const me = await api.me()
  if (!CONSOLE_ROLES.includes(me.user.role)) {
    await api.logout().catch(() => undefined)
    throw new ManagerAccountRequiredError()
  }
  return me
}

interface AuthState {
  user: AuthenticatedUser | null
  permissions: string[]
  /** True until the initial silent-refresh attempt resolves. */
  isInitialising: boolean
  /** Why the last restore/login was refused by this console (role), if it was. */
  deniedReason: string | null
  login: (identifier: string, password: string) => Promise<void>
  logout: () => Promise<void>
  can: (permission: string) => boolean
}

const AuthContext = createContext<AuthState | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthenticatedUser | null>(null)
  const [permissions, setPermissions] = useState<string[]>([])
  const [isInitialising, setIsInitialising] = useState(true)
  const [deniedReason, setDeniedReason] = useState<string | null>(null)

  const clear = useCallback(() => {
    setAccessToken(null)
    setUser(null)
    setPermissions([])
  }, [])

  // Restore the session on load. The access token is memory-only and therefore
  // gone after a reload, but the HttpOnly refresh cookie survives - so one
  // silent refresh puts the manager back where they were instead of bouncing
  // them to a login screen on every page refresh.
  useEffect(() => {
    let cancelled = false

    setUnauthenticatedHandler(() => {
      if (!cancelled) clear()
    })

    void (async () => {
      try {
        const token = await refreshSession()
        if (cancelled) return
        if (token) {
          const me = await consoleIdentity()
          if (cancelled) return
          setUser(me.user)
          setPermissions(me.permissions)
        }
      } catch (error) {
        // No usable session. Not an error worth showing - it is the normal
        // state for a first visit. A driver's session IS worth a sentence.
        if (!cancelled) {
          clear()
          if (error instanceof ManagerAccountRequiredError) {
            clearCache()
            setDeniedReason(error.message)
          }
        }
      } finally {
        if (!cancelled) setIsInitialising(false)
      }
    })()

    return () => {
      cancelled = true
      setUnauthenticatedHandler(null)
    }
  }, [clear])

  const login = useCallback(async (identifier: string, password: string) => {
    const result = await api.login(identifier, password)
    setAccessToken(result.access_token)
    try {
      const me = await consoleIdentity()
      setDeniedReason(null)
      setUser(me.user)
      setPermissions(me.permissions)
    } catch (error) {
      clear()
      clearCache()
      if (error instanceof ManagerAccountRequiredError) setDeniedReason(error.message)
      throw error
    }
  }, [clear])

  const logout = useCallback(async () => {
    try {
      await api.logout()
    } finally {
      // Clear locally even if the call failed - the user asked to leave, and
      // the refresh cookie is scoped so a stale server session cannot be used
      // from this browser without it.
      clear()
      clearCache()
    }
  }, [clear])

  const can = useCallback(
    (permission: string) => permissions.includes(permission),
    [permissions],
  )

  const value = useMemo(
    () => ({ user, permissions, isInitialising, deniedReason, login, logout, can }),
    [user, permissions, isInitialising, deniedReason, login, logout, can],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthState {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
