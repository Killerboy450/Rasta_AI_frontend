# Frontend details and PDF coverage

## What is a frontend?

The frontend is the part users see and interact with: screens, navigation,
forms, buttons, maps and feedback. The backend authenticates users, stores data,
enforces permissions and processes operations. RASTA AI has two frontend projects.

## Technologies verified from this repository snapshot

Versions below are resolved versions in the included lockfiles, not recommendations
to upgrade or descriptions inferred from old project notes.

| Area | Manager Web | Driver App |
| --- | --- | --- |
| UI framework | React 19.2.8 + React DOM | React 19.2.3 + React Native 0.86.3 |
| Language | TypeScript 6.0.3, TSX | TypeScript 6.0.3, TSX |
| Build/development | Vite 8.2.2 | Expo SDK 57.0.18 and Metro |
| Browser rendering | React DOM | React Native Web 0.21.2 |
| Styling | Tailwind CSS 4.3.3 + custom CSS/theme tokens | React Native styles + theme context and shared tokens |
| Navigation | React Router DOM 7.18.3 | Custom React state-based tab/screen switching |
| Maps | MapLibre GL 6.6.0 | Leaflet 1.9.4 in web; Leaflet inside React Native WebView on native |
| Icons | Lucide React | Expo vector icons/Feather wrappers |
| State | React hooks, contexts and API hooks | React hooks, auth/trip/language/theme providers |
| Backend clients | Local REST mode or Supabase JS 2.116.0 | Local REST mode or Supabase JS 2.115.0 |
| Tests | Vitest 3.2.7 + Testing Library | Vitest 4.1.11 and existing app tests |

Map rendering libraries draw maps and overlays; they are not the complete routing,
weather or risk backend. This source does not embed Google's proprietary Maps app.

## Requirement mapping

The PDF describes frontend setup and core screens, with registration conditional
on project needs. All eight requirement areas have matching source below.
Source coverage does not certify every live service or every device layout.

| PDF requirement | Relevant included source | Scope/evidence |
| --- | --- | --- |
| Project/repository setup | Both `package.json` and `package-lock.json`, TypeScript and build configs | Dependency install and frontend checks passed |
| Login/registration, if required | `manager-web/src/pages/LoginPage.tsx`, `driver-app/src/screens/LoginScreen.tsx`, both auth providers | Login screens and validation exist; sign-in needs backend. Driver creation is manager-controlled rather than public signup |
| Navigation structure | `manager-web/src/App.tsx`; `driver-app/App.tsx` and `src/navigation.ts` | Manager URL routes and driver tab/screen transitions |
| Dashboard | `manager-web/src/pages/FleetPage.tsx`, `components/FleetKpiBar.tsx`; `driver-app/src/screens/TripScreen.tsx` | Fleet/map dashboard and driver trip landing screen |
| Forms and input screens | Manager `DriversPage`, `TrucksPage`, `TripsPage`, `AssignTruckDialog`, `AddressPicker`; driver `AssignmentScreen`, `MyDetailsScreen` | Operational forms, location selection and input/error states |
| Main application screens | Manager `src/pages/`; driver `src/screens/` | Fleet operations, trip handling, map, safety, profile and supporting screens |
| Basic UI components | Both `src/components/ui.tsx` files | Shared controls, status, loading and message components |
| Responsive layout | Manager `src/index.css` and responsive utility classes; driver flex/scroll/safe-area layouts | Responsive source exists; manual multi-device review remains necessary |

## Screen flow

Manager:

```mermaid
flowchart TD
  A[Login] --> B{Role and permissions}
  B --> C[Fleet dashboard]
  B --> D[Route review]
  C --> E[Trips and planning]
  C --> F[Drivers and profiles]
  C --> G[Trucks and assignments]
  E --> H[Route conditions and selection]
  D --> H
```

Driver:

```mermaid
flowchart TD
  A[Login] --> B[Trip home]
  B --> C[Truck verification]
  B --> D[Accept assigned trip]
  D --> E[Navigation map]
  B --> F[Safety]
  B --> G[More]
  G --> H[Profile and assistant]
  G --> I[Language and theme]
```

The driver flow is assembled in `driver-app/App.tsx`; map opening is connected
through `TripScreen` callbacks. Available actions depend on real trip and auth state.

## Design choices

- Manager: light working surfaces and charcoal navigation, suitable for tables,
  dispatch forms and fleet monitoring.
- Driver: day/night themes, safe-area handling, scroll layouts and larger touch
  controls, suitable for phone use.
- Semantic colours: green actions/success, blue route geometry/focus, amber
  caution and red errors/emergencies.
- Manager CSS requests Inter for body text and Sora for display text, with system
  fallbacks. Font-family declarations alone do not guarantee a downloaded font;
  actual rendering depends on available fonts.
- Driver uses native/platform text rendering and shared theme styles.
- Loading, error, offline, disabled and empty states are represented in the code.
  Testing these components does not prove the backend is available.
- Driver language catalogues and controls are included; translation completeness
  and quality should be reviewed before making broad language-coverage claims.

## Explain it to a mentor in simple English

“Our frontend has two parts. The manager website uses React, TypeScript, Vite
and Tailwind CSS. It shows the fleet dashboard and forms for trips, drivers and
trucks. The driver app uses React Native and Expo. It shows assigned trips,
navigation, safety and profile screens. We use reusable components and responsive
layouts. Both frontends connect to our backend for login and real operational data.”

Gujarati: Frontend એટલે user ને દેખાતી screens, forms, buttons અને maps.
Manager માટે React website છે. Driver માટે React Native + Expo app છે.
Data save કરવું અને login verify કરવું backend નું કામ છે.

## What still needs a live demonstration

Use the existing project backend to verify successful login, authorised data,
form persistence, actual route/map data and the full manager-to-driver workflow.
Also check desktop and phone layouts manually. This packaging task did not log
into production, modify records or certify an Android device.
