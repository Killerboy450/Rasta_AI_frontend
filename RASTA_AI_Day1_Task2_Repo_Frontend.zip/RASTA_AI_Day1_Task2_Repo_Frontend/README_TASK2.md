# RASTA AI - Day 1, Task 2: repository frontend

This ZIP contains the actual Manager Web and Driver App frontend source from:

- Repository: https://github.com/nxtlucifer/ner-ai-logistics
- Branch: `main`
- Commit: `adc66a52b71725e40da41b94628f171bf376e305`
- Snapshot date: 18 September 2026
- Assignment: `task/Day_1_Task_2.pdf`

The 251 repository files listed in `SOURCE_MANIFEST.json` are copied unchanged.
The task guides, launchers and `config/` examples are additions for this ZIP.
The GitHub repository has not been changed, committed, pushed or deployed.

## What you get

| Folder/file | Purpose |
| --- | --- |
| `manager-web/` | React manager website: login, fleet dashboard, trips, drivers, trucks, assignments, route review and diagnostics |
| `driver-app/` | React Native/Expo app: login, trip, navigation map, truck verification, safety, profile, assistant, language and theme controls |
| `design-system/`, `docs/terrain/` | Repository design references; current CSS/theme source determines actual styling |
| `brand/mark.svg` | Original shared brand mark; compiled app assets are inside each frontend |
| `i18n/` | Shared language reference data |
| `supabase/functions/` | Only five existing helper/fixture files imported by frontend tests; this is NOT a complete backend deployment |
| `FRONTEND_DETAILS.md` | Technologies, source files, screen flow and PDF checklist |
| `VERIFICATION.md` | Checks performed and limits of those checks |
| `SOURCE_MANIFEST.json` | Source origin, file sizes and SHA-256 hashes |

The full FastAPI backend, database, migrations, model/data pipelines, dependencies,
build outputs and Git history are outside this frontend assignment package.

## Run on your laptop

Use Node.js 24 and npm. Verification used Node 24.19.0 and npm 11.9.0.
Extract the ZIP first. Do not run commands inside the ZIP viewer.
The first dependency installation needs internet access.

### Windows - easiest method

1. Open the extracted `RASTA_AI_Day1_Task2_Repo_Frontend` folder.
2. Double-click `START_MANAGER.bat` for the manager website.
3. Double-click `START_DRIVER_WEB.bat` for the driver app in a browser.
4. Keep both terminal windows open. Press Ctrl+C to stop a server.

The launchers install dependencies if `node_modules` is absent. They do not
configure or start a backend, create users, or bypass authentication.

### Manual commands - two terminals

Manager:

```sh
cd manager-web
npm ci
npm run dev -- --host localhost
```

Open http://localhost:5173.

Driver, in another terminal opened at the extracted package root:

```sh
cd driver-app
npm ci
npm run web -- --localhost --port 8123
```

Open http://localhost:8123.

There is no root `package.json`; run npm inside the relevant app folder.
The driver command is the Expo web preview, not an APK build.

## Backend connection: read before signing in

**Running the frontend locally does not make the complete application offline.**
The sign-in screen can load without a backend. Successful sign-in, dashboards,
trip records and form submissions need the project's working backend and valid
accounts. This ZIP does not contain an authentication bypass or invented fleet data.

Choose one connection mode for your existing environment:

| Mode | Manager configuration | Driver configuration |
| --- | --- | --- |
| Existing local FastAPI server | Copy `config/manager.local.env.example` to `manager-web/.env.local` | Copy `config/driver.local.env.example` to `driver-app/.env` |
| Existing configured Supabase project | Copy `config/manager.supabase.env.example` to `manager-web/.env.local`, then fill its public values | Copy `config/driver.supabase.env.example` to `driver-app/.env`, then fill its public values |

Restart the development server after editing environment files. Use only one
mode's file per frontend. Check existing environment variables if mode selection
does not match what you configured.

For local mode, the examples point to `http://localhost:8000`. Keep the manager
browser and its API on `localhost` for the existing refresh-cookie behaviour.
Your backend must permit the frontend origins above. The backend installation
and database setup remain in the full repository; start an already configured
backend using that repository's instructions (`python run.py` in `backend`).

For Supabase mode, use your existing project's URL and publishable key (or the
supported legacy anon key), with its existing schema, policies, functions and
accounts. Public environment variables are visible in the browser/app bundle;
never place a service-role key, secret key or password in them. These examples
do not create or change any Supabase resources.

The original app `.env.example` files focus on local mode. `config/` also explains
the Supabase mode already supported by the current source. The source files are
preserved rather than rewritten for this archive.

Existing `driver-app/eas.json` is included as repository provenance. Its release
profiles are not used by the local web commands above. No EAS build or deployment
is needed for Task 2.

## Assignment and mentor walkthrough

1. Explain the two users: the manager plans/dispatches; the driver executes.
2. Show each login screen and validation/error states.
3. With your working backend and accounts, show Fleet -> Trips -> Drivers -> Trucks.
4. Show trip planning inputs and driver/truck forms.
5. In the driver interface, show Trip -> Navigate -> Safety -> More.
6. Show shared button/input/status styling, keyboard focus and smaller screen layouts.
7. Explain that public self-registration is not required here; managers provision drivers.

Do not claim a backend-dependent operation works just because its screen renders.
Map tiles and some map assets require a network connection. Offline assistant
and cached data features do not imply a fully offline map/navigation service.

## Re-run checks

Manager:

```sh
cd manager-web
npm run build
npm test
```

Driver:

```sh
cd driver-app
npm run typecheck
npm test
npx expo export --platform web --output-dir dist-web
```

Keep the included `supabase/functions/` helper paths in place: several existing
frontend tests import those files. No database connection is needed by the
frontend suites run for this package.

## Common issues

- `npm` not recognised: install Node.js, then reopen your terminal.
- Port already in use: stop the previous frontend server, then restart.
- Sign-in fails: confirm the selected backend is running/configured and use an
  account already provisioned for the correct role.
- Blank or unavailable dashboard data: investigate the API/session error; do
  not replace missing data with fake values.
- Need an Android APK: use the full project's separate Android release process;
  this ZIP is the frontend source and local web workflow for Task 2.

Read `VERIFICATION.md` for what was actually checked in this environment.
