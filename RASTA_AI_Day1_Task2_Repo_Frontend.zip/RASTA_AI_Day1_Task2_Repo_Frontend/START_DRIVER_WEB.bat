@echo off
setlocal
cd /d "%~dp0driver-app"
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js 24, then reopen this launcher.
  pause
  exit /b 1
)
if not exist node_modules (
  call npm ci --no-audit --no-fund
  if errorlevel 1 (
    echo Dependency installation failed. Check the error above.
    pause
    exit /b 1
  )
)
echo Driver web frontend: http://localhost:8123
echo Sign-in and data require your configured backend. Read README_TASK2.md.
call npm run web -- --localhost --port 8123
pause
