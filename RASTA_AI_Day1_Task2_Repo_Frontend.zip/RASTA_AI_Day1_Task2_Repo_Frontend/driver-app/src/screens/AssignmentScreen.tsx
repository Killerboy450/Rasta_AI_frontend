/**
 * The driver's current assignment, and truck verification.
 *
 * Checking the truck is a prerequisite for driving it: the backend refuses to
 * start a trip on an unverified assignment, so this screen is the gate the Trip
 * tab reports as blocked.
 *
 * Deliberately no map and no GPS status. Position belongs to a trip, not to an
 * assignment, and it is shown on the Trip tab where it is real.
 */

import { useCallback, useEffect, useState } from 'react'
import {
  Image,
  Pressable,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native'

import { api, type CurrentAssignment } from '../api/client'
import { pickPhoto, upload } from '../files/pick'
import { useAuthImage } from '../files/useAuthImage'
import { Icon } from '../components/icons'
import { useT } from '../i18n/tx'
import { Banner, Button, Field, Loading, Row, errorMessage } from '../components/ui'
import { TOUCH_TARGET } from '../theme'
import { makeStyles, useTheme } from '../theme-context'

type Status = 'loading' | 'ready' | 'error'

interface ParsedReadings {
  odometerKm?: string
  fuelPct?: number
  error?: { title: string; detail: string }
}

/**
 * Validate the two numeric fields before anything is sent.
 *
 * Blank means "not reported", which is legitimate. Anything present must be a
 * real number in range, because the alternative is a verification record that
 * looks complete and is not.
 */
function parseReadings(input: { odometer: string; fuel: string }): ParsedReadings {
  const out: ParsedReadings = {}

  const odometer = input.odometer.trim()
  if (odometer) {
    const value = Number(odometer)
    if (!Number.isFinite(value) || value < 0) {
      return {
        error: {
          title: 'Check the odometer',
          detail: 'Enter the kilometres shown on the dial, digits only.',
        },
      }
    }
    // Sent as a string: the column is NUMERIC(10,1) and a float round-trip
    // would be the one place money-and-measurement precision quietly degrades.
    out.odometerKm = odometer
  }

  const fuel = input.fuel.trim()
  if (fuel) {
    const value = Number(fuel)
    if (!Number.isInteger(value) || value < 0 || value > 100) {
      return {
        error: {
          title: 'Check the fuel level',
          detail: 'Enter a whole percentage between 0 and 100.',
        },
      }
    }
    out.fuelPct = value
  }

  return out
}

export default function AssignmentScreen({ onBack }: { onBack?: () => void } = {}) {
  const styles = useStyles()
  const { colors: COLORS } = useTheme()
  const [status, setStatus] = useState<Status>('loading')
  const [assignment, setAssignment] = useState<CurrentAssignment | null>(null)
  const [loadError, setLoadError] = useState<unknown>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)

  const [registration, setRegistration] = useState('')
  const [odometer, setOdometer] = useState('')
  const [fuel, setFuel] = useState('')
  const [damage, setDamage] = useState('')

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [verifyError, setVerifyError] = useState<{
    title: string
    detail: string
  } | null>(null)
  const [justVerified, setJustVerified] = useState(false)
  // TRUCK PHOTO. Captured on the phone, uploaded to the private files API,
  // attached to this assignment by the server; the verify button is offered
  // only once it is there. A photo already on the assignment (uploaded
  // earlier, or on a reload) counts - the server is the record.
  const [photo, setPhoto] = useState<{ uri: string; uploaded: boolean } | null>(null)
  const [photoBusy, setPhotoBusy] = useState(false)
  const t = useT()
  const serverPhoto = useAuthImage(assignment?.verification_photo_url)

  async function takePhoto(source: 'camera' | 'library') {
    setPhotoBusy(true)
    setVerifyError(null)
    try {
      const file = await pickPhoto(source)
      if (!file) return
      setPhoto({ uri: file.uri, uploaded: false })
      await upload(file, 'TRUCK_VERIFICATION')
      setPhoto({ uri: file.uri, uploaded: true })
    } catch (err) {
      setPhoto(null)
      setVerifyError({ title: t('Upload requires connection'), detail: errorMessage(err).detail })
    } finally {
      setPhotoBusy(false)
    }
  }

  const load = useCallback(async () => {
    try {
      const result = await api.myAssignment()
      setAssignment(result)
      setLoadError(null)
      setStatus('ready')
    } catch (err) {
      setLoadError(err)
      setStatus('error')
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  async function onPullToRefresh() {
    setIsRefreshing(true)
    await load()
    setIsRefreshing(false)
  }

  async function handleVerify() {
    if (isSubmitting || !assignment) return // double-submit guard

    // Checked here rather than left to the server. `Number('abc')` is NaN, and
    // JSON.stringify turns NaN into null - so a typo would reach the backend as
    // "no reading given" and be recorded as a completed check with a blank
    // odometer. The fuel field is also an integer server-side, and Android's
    // numeric keypad happily offers a decimal point.
    const readings = parseReadings({ odometer, fuel })
    if (readings.error) {
      setVerifyError(readings.error)
      return
    }

    setIsSubmitting(true)
    setVerifyError(null)
    try {
      const result = await api.verifyAssignment({
        // Sending the id we are showing lets the server reject a stale screen
        // rather than verifying a truck the manager has since reassigned.
        assignment_id: assignment.id,
        reported_registration: registration.trim() || undefined,
        reported_odometer_km: readings.odometerKm,
        reported_fuel_level_pct: readings.fuelPct,
        reported_damage_notes: damage.trim() || undefined,
      })
      setAssignment(result.assignment)
      setJustVerified(true)
    } catch (err) {
      setVerifyError(errorMessage(err))
      // A conflict usually means the assignment moved underneath us; reload so
      // the driver is looking at the truth rather than a stale screen.
      void load()
    } finally {
      setIsSubmitting(false)
    }
  }

  const verified = assignment?.verified_at != null

  return (
    <SafeAreaView style={styles.flex}>
      {onBack ? (
        <Pressable
          onPress={onBack}
          accessibilityRole="button"
          accessibilityLabel="Back to trip"
          style={styles.backRow}
        >
          <Icon name="chevron-left" size={20} color={COLORS.routeOn} />
          <Text style={styles.backText}>{t(verified ? 'Back to trip — checked' : 'Back to trip')}</Text>
        </Pressable>
      ) : null}
      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={onPullToRefresh}
            tintColor={COLORS.muted}
          />
        }
      >
        {status === 'loading' ? (
          <Loading label="Loading your assignment…" />
        ) : status === 'error' ? (
          <>
            <Banner {...errorMessage(loadError)} tone="bad" />
            <Button label="Try again" onPress={() => void load()} />
          </>
        ) : assignment === null ? (
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>{t('No truck assigned')}</Text>
            <Text style={styles.emptyBody}>
              {t('Your manager has not assigned you a truck yet. Pull down to refresh.')}
            </Text>
          </View>
        ) : (
          <>
            {justVerified ? (
              <Banner
                tone="ok"
                title="Truck verified"
                detail={
                  assignment.mismatch_flagged
                    ? 'The registration you entered does not match our records. Your manager has been notified — you can continue.'
                    : 'Your manager can see that you have checked this truck.'
                }
              />
            ) : null}

            {assignment.mismatch_flagged && !justVerified ? (
              <Banner
                tone="warn"
                title="Awaiting manager review"
                detail="The registration you reported did not match. Your manager is checking it."
              />
            ) : null}

            {/* Four steps, state carried by icon + label + colour. */}
            <View style={styles.steps} accessibilityRole="progressbar">
              {([
                ['Truck', true],
                ['Photo', Boolean(photo?.uploaded || assignment.verification_photo_url)],
                ['Plate', verified || registration.trim().length > 0],
                ['Confirm', verified],
              ] as Array<[string, boolean]>).map(([label, done], i, all) => {
                const current = !done && all.slice(0, i).every(([, d]) => d)
                return (
                  <View key={label} style={styles.step}>
                    <View style={[styles.stepDot, done && styles.stepDotDone, current && styles.stepDotNow]}>
                      {done ? <Icon name="check" size={13} color={COLORS.onAccent} /> : <Text style={[styles.stepNum, current && styles.stepNumNow]}>{i + 1}</Text>}
                    </View>
                    <Text style={[styles.stepLabel, (done || current) && styles.stepLabelOn]} numberOfLines={1}>{t(label)}</Text>
                  </View>
                )
              })}
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>{t('Your truck')}</Text>
              <Text style={styles.registration}>
                {assignment.truck.registration_number}
              </Text>
              <Row
                label="Type"
                value={
                  [assignment.truck.make, assignment.truck.model]
                    .filter(Boolean)
                    .join(' ') ||
                  assignment.truck.truck_type ||
                  '—'
                }
              />
              <Row
                label="Capacity"
                value={`${Number(assignment.truck.max_capacity_kg).toLocaleString()} kg`}
              />
              <Row
                label="Verified"
                value={
                  verified
                    ? new Date(assignment.verified_at as string).toLocaleDateString()
                    : t('Not yet')
                }
              />
            </View>

            {verifyError ? (
              <Banner tone="bad" {...verifyError} />
            ) : null}

            {verified ? null : (
              <View style={styles.card}>
                <Text style={styles.cardTitle}>{t('Check the truck')}</Text>
                <Text style={styles.help}>
                  {t('Enter what you can see on the vehicle. If the registration does not match, you can still continue — your manager will review it.')}
                </Text>
                <Text style={styles.fieldLabel}>{t('Truck photo')}</Text>
                {photo ? (
                  <Image source={{ uri: photo.uri }} style={styles.photo} accessibilityLabel="Truck photo" testID="truck-photo" />
                ) : serverPhoto ? (
                  <Image source={{ uri: serverPhoto }} style={styles.photo} accessibilityLabel="Truck photo" testID="truck-photo" />
                ) : null}
                <View style={styles.photoRow}>
                  <View style={styles.photoCell}><Button label={t('Camera')} variant="secondary" busy={photoBusy} onPress={() => void takePhoto('camera')} /></View>
                  <View style={styles.photoCell}><Button label={t('Gallery')} variant="secondary" busy={photoBusy} onPress={() => void takePhoto('library')} /></View>
                </View>
                <Text style={styles.help}>
                  {photo?.uploaded || assignment.verification_photo_url ? t('Photo uploaded') : t('Take a photo of the truck before you verify.')}
                </Text>
                <Field
                  label={t('Registration on the truck')}
                  value={registration}
                  onChangeText={setRegistration}
                  placeholder={assignment.truck.registration_number}
                  autoCapitalize="characters"
                />
                <Field
                  label="Odometer (km)"
                  value={odometer}
                  onChangeText={setOdometer}
                  keyboardType="numeric"
                />
                <Field
                  label="Fuel level (%)"
                  value={fuel}
                  onChangeText={setFuel}
                  keyboardType="numeric"
                />
                <Field
                  label="Visible damage"
                  value={damage}
                  onChangeText={setDamage}
                  placeholder="Leave blank if none"
                  autoCapitalize="none"
                  returnKeyType="go"
                  onSubmitEditing={() => void handleVerify()}
                />
                <Button
                  label={isSubmitting ? '…' : t('Verify truck')}
                  onPress={handleVerify}
                  busy={isSubmitting}
                  disabled={!(photo?.uploaded || assignment.verification_photo_url) || !registration.trim()}
                />
              </View>
            )}

            <Text style={styles.note}>
              {t(verified
                ? 'This truck is checked. Location is shared only while a trip is running — see the Trip tab.'
                : 'Check this truck before you can start a trip. Location is not being shared.')}
            </Text>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const useStyles = makeStyles((COLORS) => ({
  flex: { flex: 1, backgroundColor: COLORS.bg },
  backRow: { minHeight: TOUCH_TARGET, flexDirection: 'row', alignItems: 'center', gap: 2, paddingHorizontal: 16 },
  backText: { color: COLORS.routeOn, fontSize: 15, fontWeight: '700' },
  container: { padding: 20, paddingBottom: 48 },
  card: {
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 12,
    padding: 18,
    marginBottom: 16,
  },
  cardTitle: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  registration: {
    color: COLORS.text,
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: 1,
    marginTop: 6,
    marginBottom: 10,
  },
  help: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginVertical: 12 },
  fieldLabel: { color: COLORS.muted, fontSize: 12, fontWeight: '700', marginTop: 4 },
  photo: { width: '100%', height: 180, borderRadius: 12, backgroundColor: COLORS.dim, marginTop: 8 },
  photoRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  steps: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 16, paddingHorizontal: 4 },
  step: { flex: 1, alignItems: 'center', gap: 6 },
  stepDot: { width: 28, height: 28, borderRadius: 14, borderWidth: 2, borderColor: COLORS.borderStrong, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.card },
  stepDotDone: { backgroundColor: COLORS.accent, borderColor: COLORS.accent },
  stepDotNow: { borderColor: COLORS.accent },
  stepNum: { color: COLORS.faint, fontSize: 12, fontWeight: '800' },
  stepNumNow: { color: COLORS.accent },
  stepLabel: { color: COLORS.faint, fontSize: 11, fontWeight: '700' },
  stepLabelOn: { color: COLORS.text },
  photoCell: { flex: 1, minWidth: 0 },

  empty: { alignItems: 'center', paddingVertical: 56 },
  emptyTitle: { color: COLORS.text, fontSize: 18, fontWeight: '700' },
  emptyBody: {
    color: COLORS.muted,
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 20,
    maxWidth: 300,
  },

  note: { color: COLORS.faint, fontSize: 12, marginTop: 24, lineHeight: 18 },
}))
